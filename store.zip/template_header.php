<div class="header">
	<div class="header-top">
		<div class="container">
       		 <div class="col-sm-4 world"></div>
			 <div class="col-sm-4 logo">
			 	<a href="index.php"><img src="images/logo.png" alt="" width="268" height="83"></a>	
			 </div>
			<div class="col-sm-4 header-left">					
				<div class="cart box_1">
					<a href="checkout.html">
						<h3> 
							<a href="shoppingcart.php"><img src="images/cart.png" alt="" width="28" height="29"/></a>
                    	</h3>
					</a>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
    <div class="container">
    	<div class="head-top">
		<ul class="memenu skyblue">
			<li><a  href="index.php">Home</a></li>	
           <li><a></a></li>
    		<li><a href="index.php#nikeahchor">Nike</a></li>
			<li><a href="index.php#UAahchor">UA</a></li>
			<li><a href="index.php#reebokahchor">Reebok</a></li>				
		</ul> 
    	</div>
    </div>
</div>