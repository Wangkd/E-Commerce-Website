<div class="footer">
	<div class="footer-bottom">
		<div class="container">
			<div class="clearfix"> </div>
				<p class="footer-class">@copyright | Enjoy shopping! </p>
		</div>
	</div>
</div>   